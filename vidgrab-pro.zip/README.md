# 🎬 VidGrab Pro - Video Downloader

Aplikasi web untuk mendownload video dari TikTok, YouTube, Instagram, Facebook, Twitter/X, Vimeo, Dailymotion, dan platform lainnya menggunakan **yt-dlp**.

---

## 📋 Persyaratan

- **VPS / Server** dengan OS Linux (Ubuntu/Debian/CentOS)
- **Node.js** v16+ 
- **Python 3** + **pip**
- **yt-dlp** (Python library)
- **FFmpeg** (untuk merge video + audio)

---

## 🚀 Cara Install di VPS (Ubuntu/Debian)

### 1. Install Node.js
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### 2. Install Python, pip, FFmpeg
```bash
sudo apt update
sudo apt install -y python3 python3-pip ffmpeg
```

### 3. Install yt-dlp
```bash
pip3 install yt-dlp
# atau
sudo pip3 install yt-dlp
```

### 4. Upload Project ke VPS
Gunakan **SFTP** atau **SCP** untuk upload folder `vidgrab-pro` ke VPS, atau clone dari git.

```bash
cd /var/www
# Upload folder vidgrab-pro ke sini
cd vidgrab-pro
```

### 5. Install Dependencies
```bash
npm install
```

### 6. Jalankan Server
```bash
# Mode production
npm start

# Mode development (auto-restart saat edit file)
npm run dev
```

Server akan berjalan di port **3000**.

---

## 🔧 Setup dengan PM2 (Production)

Agar server tetap berjalan 24/7:

```bash
# Install PM2
sudo npm install -g pm2

# Jalankan dengan PM2
pm2 start server.js --name vidgrab

# Simpan konfigurasi
pm2 save
pm2 startup
```

---

## 🌐 Setup Domain + SSL (Nginx)

### 1. Install Nginx
```bash
sudo apt install -y nginx
```

### 2. Konfigurasi Nginx
Buat file `/etc/nginx/sites-available/vidgrab`:

```nginx
server {
    listen 80;
    server_name domain-anda.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Aktifkan:
```bash
sudo ln -s /etc/nginx/sites-available/vidgrab /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 3. Install SSL (Let's Encrypt)
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d domain-anda.com
```

---

## 🐳 Docker (Alternatif)

Buat `Dockerfile`:

```dockerfile
FROM node:18
RUN apt-get update && apt-get install -y python3 python3-pip ffmpeg
RUN pip3 install yt-dlp
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["node", "server.js"]
```

Build & run:
```bash
docker build -t vidgrab .
docker run -p 3000:3000 vidgrab
```

---

## 📁 Struktur Folder

```
vidgrab-pro/
├── server.js          # Backend Express + yt-dlp
├── package.json       # Dependencies
├── public/
│   └── index.html     # Frontend
├── downloads/         # Folder sementara file download
└── README.md          # Dokumentasi ini
```

---

## 🔌 API Endpoints

| Endpoint | Method | Parameter | Keterangan |
|----------|--------|-----------|------------|
| `/api/status` | GET | - | Cek status server & yt-dlp |
| `/api/info` | GET | `url` | Ambil info video & daftar kualitas |
| `/api/download` | GET | `url`, `formatId`, `filename` | Download video/audio |
| `/downloads/:file` | GET | - | Download file yang sudah diproses |

---

## ✅ Platform yang Didukung

| Platform | Video | Audio | Catatan |
|----------|-------|-------|---------|
| **TikTok** | ✅ | ✅ | Tanpa watermark |
| **YouTube** | ✅ | ✅ | Semua kualitas |
| **Instagram** | ✅ | ❌ | Reels, Posts, Stories |
| **Facebook** | ✅ | ❌ | Video & Watch |
| **Twitter/X** | ✅ | ❌ | Video & GIF |
| **Vimeo** | ✅ | ❌ | HD & 4K |
| **Dailymotion** | ✅ | ✅ | Semua video |
| **SoundCloud** | ❌ | ✅ | Audio only |

---

## ⚠️ Catatan Penting

1. **yt-dlp** harus selalu di-update karena platform sering mengubah API:
   ```bash
   pip3 install -U yt-dlp
   ```

2. **Rate Limiting** - Beberapa platform (terutama TikTok) bisa memblokir IP. Gunakan proxy/rotasi IP jika traffic tinggi.

3. **Legal** - Pastikan Anda memiliki hak untuk mendownload konten. Aplikasi ini untuk keperluan pribadi/edukasi.

4. **Storage** - File download otomatis dihapus setelah 1 jam untuk hemat storage.

---

## 🛠 Troubleshooting

### yt-dlp tidak ditemukan
```bash
which yt-dlp
# Jika tidak ada, install ulang:
pip3 install --user yt-dlp
# atau
sudo pip3 install yt-dlp
```

### FFmpeg tidak ditemukan
```bash
sudo apt install ffmpeg
```

### Permission denied
```bash
chmod +x server.js
sudo chown -R $USER:$USER /var/www/vidgrab-pro
```

---

## 📄 Lisensi

MIT License - Gunakan dengan bijak.
