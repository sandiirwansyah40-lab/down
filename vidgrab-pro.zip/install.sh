#!/bin/bash
# VidGrab Pro - Auto Install Script for Ubuntu/Debian VPS

echo "╔══════════════════════════════════════════════╗"
echo "║     🎬 VidGrab Pro - Auto Installer        ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# Warna
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Update system
echo -e "${YELLOW}[1/7] Updating system...${NC}"
sudo apt update && sudo apt upgrade -y

# Install Node.js
echo -e "${YELLOW}[2/7] Installing Node.js...${NC}"
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install Python, pip, FFmpeg
echo -e "${YELLOW}[3/7] Installing Python, pip, FFmpeg...${NC}"
sudo apt install -y python3 python3-pip ffmpeg

# Install yt-dlp
echo -e "${YELLOW}[4/7] Installing yt-dlp...${NC}"
pip3 install yt-dlp

# Verify installations
echo -e "${YELLOW}[5/7] Verifying installations...${NC}"
node -v
python3 --version
ffmpeg -version | head -1
yt-dlp --version

# Install Node dependencies
echo -e "${YELLOW}[6/7] Installing Node dependencies...${NC}"
npm install

# Create downloads folder
mkdir -p downloads

# Install PM2
echo -e "${YELLOW}[7/7] Installing PM2...${NC}"
sudo npm install -g pm2

echo ""
echo -e "${GREEN}✅ Installasi selesai!${NC}"
echo ""
echo "Untuk menjalankan server:"
echo "  npm start          → Mode biasa"
echo "  npm run dev        → Mode development"
echo "  pm2 start server.js --name vidgrab  → Mode production"
echo ""
echo "Buka browser ke: http://$(hostname -I | awk '{print $1}'):3000"
echo ""
