const express = require('express');
const cors = require('cors');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Pastikan folder downloads ada
const downloadsDir = path.join(__dirname, 'downloads');
if (!fs.existsSync(downloadsDir)) {
    fs.mkdirSync(downloadsDir, { recursive: true });
}

// ============================================
// API ENDPOINTS
// ============================================

// 1. Cek info video (tanpa download)
app.get('/api/info', async (req, res) => {
    const { url } = req.query;

    if (!url) {
        return res.status(400).json({ error: 'URL diperlukan' });
    }

    console.log('[INFO] Menganalisis:', url);

    // Jalankan yt-dlp untuk ambil info
    const cmd = `yt-dlp --dump-json --no-download "${url}"`;

    exec(cmd, { timeout: 30000 }, (error, stdout, stderr) => {
        if (error) {
            console.error('[ERROR] yt-dlp info:', error.message);
            return res.status(500).json({ 
                error: 'Gagal menganalisis video',
                detail: error.message 
            });
        }

        try {
            const info = JSON.parse(stdout);

            // Format kualitas yang tersedia
            const formats = info.formats
                .filter(f => f.ext === 'mp4' || f.ext === 'webm' || f.ext === 'm4a')
                .map(f => ({
                    formatId: f.format_id,
                    quality: f.quality_label || f.format_note || 'unknown',
                    resolution: f.resolution || 'audio',
                    ext: f.ext,
                    size: f.filesize ? formatBytes(f.filesize) : 'Unknown',
                    hasAudio: f.acodec !== 'none',
                    hasVideo: f.vcodec !== 'none'
                }))
                .filter(f => f.hasVideo || f.resolution === 'audio')
                .slice(0, 10);

            // Tambah opsi audio-only
            if (info.extractor !== 'soundcloud') {
                formats.push({
                    formatId: 'bestaudio',
                    quality: 'Audio Only (MP3)',
                    resolution: 'audio',
                    ext: 'mp3',
                    size: 'Auto',
                    hasAudio: true,
                    hasVideo: false
                });
            }

            res.json({
                success: true,
                title: info.title,
                author: info.uploader || info.channel || 'Unknown',
                duration: formatDuration(info.duration),
                thumbnail: info.thumbnail,
                views: formatNumber(info.view_count),
                platform: info.extractor,
                formats: formats
            });

        } catch (e) {
            console.error('[ERROR] Parse JSON:', e.message);
            res.status(500).json({ error: 'Gagal parsing data video' });
        }
    });
});

// 2. Download video/audio
app.get('/api/download', async (req, res) => {
    const { url, formatId, filename } = req.query;

    if (!url) {
        return res.status(400).json({ error: 'URL diperlukan' });
    }

    const id = uuidv4();
    const outputPath = path.join(downloadsDir, `${id}.%(ext)s`);

    let cmd;
    if (formatId === 'bestaudio') {
        // Download audio only, convert ke MP3
        cmd = `yt-dlp -f "bestaudio" --extract-audio --audio-format mp3 --audio-quality 0 -o "${outputPath}" "${url}"`;
    } else if (formatId) {
        // Download format spesifik
        cmd = `yt-dlp -f "${formatId}+bestaudio/best" --merge-output-format mp4 -o "${outputPath}" "${url}"`;
    } else {
        // Default: best quality
        cmd = `yt-dlp -f "best[ext=mp4]/best" -o "${outputPath}" "${url}"`;
    }

    console.log('[DOWNLOAD] Memulai:', url, 'Format:', formatId || 'best');

    exec(cmd, { timeout: 120000, maxBuffer: 1024 * 1024 * 10 }, (error, stdout, stderr) => {
        if (error) {
            console.error('[ERROR] Download:', error.message);
            return res.status(500).json({ 
                error: 'Gagal mendownload',
                detail: error.message 
            });
        }

        // Cari file yang sudah didownload
        const files = fs.readdirSync(downloadsDir);
        const downloadedFile = files.find(f => f.startsWith(id));

        if (!downloadedFile) {
            return res.status(500).json({ error: 'File tidak ditemukan setelah download' });
        }

        const filePath = path.join(downloadsDir, downloadedFile);
        const stats = fs.statSync(filePath);

        res.json({
            success: true,
            downloadUrl: `/downloads/${downloadedFile}`,
            filename: filename ? `${filename}.${downloadedFile.split('.').pop()}` : downloadedFile,
            size: formatBytes(stats.size),
            message: 'Download berhasil!'
        });

        console.log('[SUCCESS] Download selesai:', downloadedFile);
    });
});

// 3. Serve file download
app.get('/downloads/:file', (req, res) => {
    const filePath = path.join(downloadsDir, req.params.file);

    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: 'File tidak ditemukan' });
    }

    res.download(filePath, req.params.file, (err) => {
        if (err) {
            console.error('[ERROR] Serve file:', err);
        }
        // Hapus file setelah 1 jam (opsional, untuk hemat storage)
        setTimeout(() => {
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
                console.log('[CLEANUP] File dihapus:', req.params.file);
            }
        }, 3600000);
    });
});

// 4. Cek status yt-dlp
app.get('/api/status', (req, res) => {
    exec('yt-dlp --version', (error, stdout) => {
        if (error) {
            res.json({ 
                ready: false, 
                message: 'yt-dlp belum terinstall. Jalankan: npm run setup' 
            });
        } else {
            res.json({ 
                ready: true, 
                version: stdout.trim(),
                message: 'Server siap!' 
            });
        }
    });
});

// ============================================
// HELPER FUNCTIONS
// ============================================

function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

function formatDuration(seconds) {
    if (!seconds) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function formatNumber(num) {
    if (!num) return '0';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}

// ============================================
// START SERVER
// ============================================

app.listen(PORT, () => {
    console.log('╔════════════════════════════════════════╗');
    console.log('║     🎬 VidGrab Pro Server Running     ║');
    console.log('╠════════════════════════════════════════╣');
    console.log(`║  Port: ${PORT.toString().padEnd(33)} ║`);
    console.log(`║  URL:  http://localhost:${PORT}${' '.repeat(17 - PORT.toString().length)} ║`);
    console.log('║                                        ║');
    console.log('║  Pastikan yt-dlp sudah terinstall:     ║');
    console.log('║  pip install yt-dlp                    ║');
    console.log('╚════════════════════════════════════════╝');
});
